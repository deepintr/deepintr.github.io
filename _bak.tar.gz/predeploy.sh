#! /bin/bash

# Make sure 404 page is exact copy of index.html.
cp index.html 404.html